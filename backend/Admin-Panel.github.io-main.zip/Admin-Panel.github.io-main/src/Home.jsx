import React from 'react'
import Dashboard from './Pages/Dashboard'

export default function Home() {
  return (
    <>
    <section className='w-full'>
      <Dashboard/>
    </section>
    </>
  )
}

